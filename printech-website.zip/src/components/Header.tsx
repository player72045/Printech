import { useState } from "react";
import { Phone, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";
import logo from "@/assets/logo-printech.png";

const navItems = [
  { label: "Home", path: "/" },
  { label: "Services", path: "/services" },
  { label: "Products", path: "/products" },
  { label: "AMC Plans", path: "/amc-plans" },
  { label: "About", path: "/about" },
  { label: "Contact", path: "/contact" },
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground text-sm py-2 hidden md:block">
        <div className="container-wide flex justify-between items-center">
          <span>Sales, Service & Support for All Printer Brands | Same-Day On-Site Service in Kolkata</span>
          <a href="tel:7870938693" className="flex items-center gap-1 hover:underline">
            <Phone size={14} /> 7870938693
          </a>
        </div>
      </div>

      {/* Main header */}
      <header className="bg-background sticky top-0 z-50 shadow-sm border-b border-border">
        <div className="container-wide flex items-center justify-between h-18 md:h-24">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo} alt="Printech Imaging Solution" className="h-16 md:h-20 w-auto" />
          </Link>

          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`text-sm font-medium transition-colors ${location.pathname === item.path ? "text-primary" : "text-foreground hover:text-primary"}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a href="tel:7870938693" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-primary">
              <Phone size={16} /> 7870938693
            </a>
            <Button asChild className="hidden sm:inline-flex bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/contact">Book Service</Link>
            </Button>
            <button className="lg:hidden p-2" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <div className="container-wide py-4 flex flex-col gap-3">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`text-left py-2 text-sm font-medium ${location.pathname === item.path ? "text-primary" : "text-foreground hover:text-primary"}`}
                >
                  {item.label}
                </Link>
              ))}
              <a href="tel:7870938693" className="flex items-center gap-2 py-2 text-primary font-medium">
                <Phone size={16} /> Call: 7870938693
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Mobile sticky call bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-primary text-primary-foreground flex">
        <a href="tel:7870938693" className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium">
          <Phone size={16} /> Call Now
        </a>
        <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer" className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium bg-secondary text-secondary-foreground">
          WhatsApp
        </a>
      </div>
    </>
  );
};

export default Header;
