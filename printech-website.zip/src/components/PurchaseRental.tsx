import { useState } from "react";
import { ShoppingCart, RefreshCw, Printer, Monitor, Droplets, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

const purchaseItems = [
  { icon: Printer, title: "Laser Printers", desc: "HP, Canon, Brother & more", price: "From ₹8,999", img: "🖨️" },
  { icon: Monitor, title: "Multifunction Printers", desc: "Print, Scan, Copy & Fax", price: "From ₹14,999", img: "🖥️" },
  { icon: Droplets, title: "Ink Tank Printers", desc: "Low cost per page printing", price: "From ₹9,999", img: "🖨️" },
  { icon: Package, title: "Toners & Cartridges", desc: "Genuine & compatible options", price: "From ₹499", img: "📦" },
  { icon: Printer, title: "Refurbished Printers", desc: "Quality checked & certified", price: "From ₹4,999", img: "♻️" },
  { icon: Package, title: "Printer Accessories", desc: "Drums, fusers, rollers & more", price: "From ₹299", img: "🔧" },
];

const rentalItems = [
  { icon: Printer, title: "B&W Laser Rental", desc: "Ideal for office documents", price: "From ₹999/mo", img: "🖨️" },
  { icon: Monitor, title: "Color MFP Rental", desc: "Print, scan & copy in color", price: "From ₹2,499/mo", img: "🖥️" },
  { icon: Printer, title: "High-Volume Rental", desc: "For large offices & teams", price: "From ₹3,999/mo", img: "🏢" },
  { icon: Package, title: "Event Printer Rental", desc: "Short-term & daily rentals", price: "From ₹500/day", img: "🎪" },
  { icon: Monitor, title: "Copier Rental", desc: "Heavy-duty copier machines", price: "From ₹4,999/mo", img: "📄" },
  { icon: Printer, title: "Custom Plans", desc: "Tailored to your business needs", price: "Get a Quote", img: "📋" },
];

const PurchaseRental = () => {
  const [active, setActive] = useState<"purchase" | "rental">("purchase");
  const items = active === "purchase" ? purchaseItems : rentalItems;

  return (
    <section className="section-padding bg-surface">
      <div className="container-wide">
        {/* Toggle tabs */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex rounded-xl bg-muted p-1.5 gap-1">
            <button
              onClick={() => setActive("purchase")}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold transition-all ${
                active === "purchase"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <ShoppingCart size={18} />
              Purchase
            </button>
            <button
              onClick={() => setActive("rental")}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold transition-all ${
                active === "rental"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <RefreshCw size={18} />
              Rental
            </button>
          </div>
        </div>

        {/* Section heading */}
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            {active === "purchase" ? "Buy Printers & Supplies" : "Rent a Printer"}
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            {active === "purchase"
              ? "Explore new & refurbished printers, toners and accessories at the best prices in Kolkata"
              : "Flexible printer rental plans for offices, events & businesses — no heavy upfront cost"}
          </p>
        </div>

        {/* Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.25 }}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4"
          >
            {items.map((item, i) => (
              <motion.a
                key={item.title}
                href="https://wa.me/917870938693"
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="group bg-card rounded-xl border border-border p-4 text-center hover:shadow-lg hover:border-primary/40 transition-all cursor-pointer"
              >
                <div className="text-4xl mb-3">{item.img}</div>
                <h3 className="text-sm font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-muted-foreground mb-2 leading-snug">{item.desc}</p>
                <span className="text-xs font-bold text-primary">{item.price}</span>
              </motion.a>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* CTA */}
        <div className="text-center mt-8">
          <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
            <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer">
              {active === "purchase" ? "Browse All Products" : "Get Rental Quote"} →
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PurchaseRental;
