import { Phone, MapPin } from "lucide-react";
import logo from "@/assets/logo-printech.png";

const areas = ["Salt Lake", "New Town", "Howrah", "Garia", "Dumdum", "Park Street", "Behala", "Ballygunge", "Jadavpur", "Rajarhat"];

const Footer = () => (
  <footer className="bg-foreground text-background">
    <div className="container-wide py-12 md:py-16">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <img src={logo} alt="Printech Imaging Solution" className="h-14 w-auto brightness-0 invert" />
          </div>
          <p className="opacity-70 leading-relaxed mb-4">
            Kolkata's trusted partner for printer sales, repair and maintenance since 2010. Serving homes and businesses with genuine parts and certified technicians.
          </p>
          <div className="flex items-center gap-2 opacity-80">
            <Phone size={16} />
            <a href="tel:7870938693" className="hover:underline">7870938693</a>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-lg mb-4">Quick Links</h3>
          <ul className="space-y-2 opacity-70">
            {["Home", "Services", "Products", "AMC Plans", "About", "Contact"].map((l) => (
              <li key={l}>
                <button
                  onClick={() => document.getElementById(l.toLowerCase().replace(/\s/g, "-"))?.scrollIntoView({ behavior: "smooth" })}
                  className="hover:opacity-100 hover:underline transition-opacity"
                >
                  {l}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><MapPin size={18} /> Service Areas</h3>
          <div className="flex flex-wrap gap-2">
            {areas.map((a) => (
              <span key={a} className="text-sm px-3 py-1 rounded-full border border-background/20 opacity-70">{a}</span>
            ))}
          </div>
        </div>
      </div>
    </div>

    <div className="border-t border-background/10">
      <div className="container-wide py-4 flex flex-col md:flex-row justify-between items-center gap-2 text-sm opacity-60">
        <p>© 2026 Printech Imaging Solution. All rights reserved.</p>
        <p>GST Registered | Kolkata, West Bengal</p>
      </div>
    </div>
  </footer>
);

export default Footer;
