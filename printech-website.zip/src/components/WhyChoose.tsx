import { ShieldCheck, Cpu, Clock, Award } from "lucide-react";
import { motion } from "framer-motion";

const reasons = [
  { icon: ShieldCheck, title: "Certified Technicians", desc: "Factory-trained engineers with expertise across all major printer brands" },
  { icon: Cpu, title: "Genuine Parts", desc: "We use only original and OEM-certified spare parts for lasting repairs" },
  { icon: Clock, title: "2-Hour Response", desc: "Fastest on-site response time in Kolkata — we reach you within 2 hours" },
  { icon: Award, title: "30-Day Warranty", desc: "Every repair backed by a 30-day service warranty for your peace of mind" },
];

const WhyChoose = () => (
  <section id="about" className="section-padding bg-primary text-primary-foreground">
    <div className="container-wide">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Printech?</h2>
        <p className="text-primary-foreground/80 text-lg max-w-2xl mx-auto">
          Kolkata's most trusted printer service partner with 15+ years of proven expertise
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {reasons.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="text-center"
          >
            <div className="w-16 h-16 rounded-full bg-primary-foreground/10 flex items-center justify-center mx-auto mb-4">
              <r.icon size={32} className="text-secondary" />
            </div>
            <h3 className="text-xl font-bold mb-2">{r.title}</h3>
            <p className="text-primary-foreground/75 leading-relaxed">{r.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChoose;
