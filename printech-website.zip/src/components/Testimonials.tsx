import { Star } from "lucide-react";

const reviews = [
  { name: "Rajesh Sharma", loc: "Salt Lake, Kolkata", text: "Printech fixed our office Canon printer within 2 hours of calling. The technician was professional and the charges were very reasonable. Highly recommended for any printer issue!" },
  { name: "Anita Das", loc: "New Town, Kolkata", text: "We have an AMC with Printech for our 5 HP printers. Their response time is excellent and they always use genuine parts. Our printing costs have reduced by 40% since we started the AMC." },
  { name: "Sunil Ghosh", loc: "Park Street, Kolkata", text: "Bought a refurbished printer from Printech for my home office. It's been working perfectly for 6 months. Great value for money and excellent after-sales support." },
];

const Testimonials = () => (
  <section className="section-padding bg-background">
    <div className="container-wide">
      <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-12">What Our Clients Say</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reviews.map((r) => (
          <div key={r.name} className="bg-card rounded-lg p-6 border border-border shadow-sm">
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-highlight text-highlight" />)}
            </div>
            <p className="text-muted-foreground leading-relaxed mb-4">"{r.text}"</p>
            <div>
              <p className="font-bold text-foreground">{r.name}</p>
              <p className="text-sm text-muted-foreground">{r.loc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
