import { Printer, Wrench, FileText, Droplets, Monitor, Settings } from "lucide-react";
import { motion } from "framer-motion";

const services = [
  { icon: Printer, title: "Printer Sales", desc: "New & refurbished printers from all major brands at competitive prices with installation support." },
  { icon: Wrench, title: "On-Site Repair", desc: "Expert technicians at your doorstep within 2 hours across Kolkata. Same-day resolution guaranteed." },
  { icon: FileText, title: "AMC Plans", desc: "Annual Maintenance Contracts starting ₹2,999/year with free pickup & drop service." },
  { icon: Droplets, title: "Toner Refill", desc: "Genuine & compatible toner cartridge refilling for all printer brands. Save up to 60%." },
  { icon: Monitor, title: "Installation", desc: "Complete printer setup including driver installation, network configuration & testing." },
  { icon: Settings, title: "Hardware & Software Support", desc: "Comprehensive troubleshooting for hardware failures, driver issues & connectivity problems." },
];

const ServicesGrid = () => (
  <section id="services" className="section-padding bg-surface">
    <div className="container-wide">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Complete printer solutions for homes and businesses across Kolkata
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-lg p-6 shadow-sm border border-border hover:shadow-md hover:border-primary/30 transition-all group"
          >
            <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
              <s.icon size={28} className="text-primary" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">{s.title}</h3>
            <p className="text-muted-foreground leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesGrid;
