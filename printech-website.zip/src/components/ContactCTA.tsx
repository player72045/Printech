import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const ContactCTA = () => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      toast.success("Thank you! We'll contact you within 30 minutes.");
      (e.target as HTMLFormElement).reset();
      setLoading(false);
    }, 800);
  };

  return (
    <section id="contact" className="section-padding bg-surface">
      <div className="container-wide">
        {/* CTA strip */}
        <div className="bg-secondary rounded-xl p-8 md:p-12 text-center text-secondary-foreground mb-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-3">🚚 Free Pickup & Drop for AMC Customers</h2>
          <p className="text-lg opacity-90">Sign up for an Annual Maintenance Contract and enjoy hassle-free printer service at your doorstep</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Get In Touch</h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Need a quick quote or want to schedule a service? Fill the form and our team will get back to you within 30 minutes during business hours.
            </p>
            <div className="space-y-4 text-foreground">
              <p><strong>📞 Phone:</strong> <a href="tel:7870938693" className="text-primary hover:underline">7870938693</a></p>
              <p><strong>📍 Location:</strong> Kolkata, West Bengal, India</p>
              <p><strong>🕐 Hours:</strong> Mon – Sat, 9:00 AM – 7:00 PM</p>
              <p><strong>📧 WhatsApp:</strong> <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Chat with us</a></p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-card rounded-lg p-6 md:p-8 border border-border shadow-sm space-y-4">
            <Input name="name" placeholder="Your Name *" required maxLength={100} className="bg-background" />
            <Input name="phone" type="tel" placeholder="Phone Number *" required maxLength={15} className="bg-background" />
            <Input name="address" placeholder="Your Address in Kolkata" maxLength={200} className="bg-background" />
            <Input name="model" placeholder="Printer Brand / Model" maxLength={100} className="bg-background" />
            <Textarea name="issue" placeholder="Describe your issue *" required maxLength={500} rows={4} className="bg-background resize-none" />
            <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-primary/90" size="lg">
              {loading ? "Submitting..." : "Book Service Now"}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;
