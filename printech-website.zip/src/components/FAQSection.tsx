import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  { q: "My printer has a paper jam that won't clear", a: "Paper jams can be caused by worn rollers, incorrect paper size, or debris inside the printer. Our technicians carefully disassemble the printer path, remove jammed paper without damaging components, and clean the rollers to prevent recurrence. On-site service available across Kolkata." },
  { q: "Printer shows offline even though it's connected", a: "This is usually a driver or network configuration issue. We check your printer's network settings, reinstall drivers, configure IP addressing, and ensure proper communication between your computer and printer. Most offline issues are resolved within 30 minutes." },
  { q: "Print quality is poor — lines, smudges or faded output", a: "Poor print quality can result from low toner, clogged print heads, or worn drum units. We diagnose the exact cause, clean or replace affected components, and calibrate your printer for optimal output quality." },
  { q: "Printer driver issues after Windows update", a: "Windows updates often break printer drivers. We install the latest compatible drivers from the manufacturer, configure printer settings, and test all functions including scanning and copying to ensure everything works perfectly." },
  { q: "Ink/toner cartridge not detected by the printer", a: "This can be caused by a faulty cartridge chip, dirty contacts, or firmware issues. We clean cartridge contacts, reset the printer's cartridge recognition system, and if needed, replace with genuine compatible cartridges at affordable prices." },
];

const FAQSection = () => (
  <section className="section-padding bg-background">
    <div className="container-wide max-w-3xl">
      <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-12">Common Issues We Fix</h2>
      <Accordion type="single" collapsible className="space-y-3">
        {faqs.map((f, i) => (
          <AccordionItem key={i} value={`faq-${i}`} className="border border-border rounded-lg px-4 bg-card">
            <AccordionTrigger className="text-left text-foreground font-medium hover:text-primary">{f.q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground leading-relaxed">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  </section>
);

export default FAQSection;
