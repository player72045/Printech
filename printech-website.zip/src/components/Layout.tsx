import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import AIChatbot from "@/components/AIChatbot";

const Layout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen pb-14 md:pb-0">
    <Header />
    <main>{children}</main>
    <Footer />
    <WhatsAppFloat />
    <AIChatbot />
  </div>
);

export default Layout;
