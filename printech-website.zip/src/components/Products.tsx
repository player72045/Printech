import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const products = [
  { name: "Konica Minolta bizhub C257i", category: "Color MFP", price: "₹1,25,000", tag: "New" },
  { name: "Konica Minolta bizhub 226i", category: "B&W MFP", price: "₹65,000", tag: "New" },
  { name: "Kyocera TASKalfa 2554ci", category: "Color MFP", price: "₹1,45,000", tag: "New" },
  { name: "Kyocera ECOSYS M2540dn", category: "B&W MFP", price: "₹42,999", tag: "Bestseller" },
  { name: "Canon imageRUNNER 2625i", category: "B&W MFP", price: "₹78,000", tag: "New" },
  { name: "Canon imageRUNNER C3226", category: "Color MFP", price: "₹1,35,000", tag: "New" },
  { name: "HP LaserJet Pro MFP", category: "Multifunction Printer", price: "₹18,999", tag: "New" },
  { name: "Epson L3250", category: "Ink Tank Wi-Fi Printer", price: "₹14,999", tag: "New" },
  { name: "Compatible Toner Cartridges", category: "All Brands Available", price: "From ₹499", tag: "Consumables" },
];

const Products = () => (
  <section id="products" className="section-padding bg-surface">
    <div className="container-wide">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Products</h2>
        <p className="text-muted-foreground text-lg">New & refurbished printers, toners and cartridges at best prices</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((p, i) => (
          <motion.div
            key={p.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="bg-card rounded-lg border border-border overflow-hidden hover:shadow-md transition-shadow"
          >
            <div className="h-48 bg-muted flex items-center justify-center relative">
              <span className="text-4xl">🖨️</span>
              <span className="absolute top-3 right-3 bg-primary text-primary-foreground text-xs font-medium px-2.5 py-1 rounded-full">
                {p.tag}
              </span>
            </div>
            <div className="p-5">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{p.category}</p>
              <h3 className="text-lg font-bold text-foreground mb-2">{p.name}</h3>
              <p className="text-xl font-bold text-primary mb-4">{p.price}</p>
              <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer">Enquire Now</a>
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Products;
