const brands = ["HP", "Canon", "Epson", "Brother", "Samsung", "Kyocera", "Xerox"];

const BrandsStrip = () => (
  <section className="section-padding bg-background">
    <div className="container-wide">
      <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-12">Brands We Service</h2>
      <div className="flex flex-wrap justify-center items-center gap-8 md:gap-14">
        {brands.map((b) => (
          <div
            key={b}
            className="w-28 h-20 rounded-lg border border-border bg-card flex items-center justify-center text-xl font-bold text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors"
          >
            {b}
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default BrandsStrip;
