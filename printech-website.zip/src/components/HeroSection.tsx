import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { useRef } from "react";

import heroImg from "@/assets/hero-printer.jpg";
import sliderKonica1 from "@/assets/slider-konica1.jpg";
import sliderKonica2 from "@/assets/slider-konica2.jpg";
import sliderKyocera1 from "@/assets/slider-kyocera1.jpg";
import sliderKyocera2 from "@/assets/slider-kyocera2.jpg";

const slides = [
  { img: heroImg, alt: "Professional printer service in Kolkata", headline: "Printer Not Working?", sub: "Get Expert Service Today", highlight: "in Kolkata" },
  { img: sliderKonica1, alt: "Konica Minolta bizhub multifunction printer", headline: "Konica Minolta", sub: "Enterprise MFP Solutions", highlight: "Available Now" },
  { img: sliderKonica2, alt: "Konica Minolta production printer", headline: "Production Printing", sub: "Konica Minolta AccurioPress", highlight: "High Volume" },
  { img: sliderKyocera1, alt: "Kyocera TASKalfa multifunction printer", headline: "Kyocera TASKalfa", sub: "Reliable & Eco-Friendly", highlight: "Office Ready" },
  { img: sliderKyocera2, alt: "Kyocera ECOSYS desktop printer", headline: "Kyocera ECOSYS", sub: "Compact Desktop Printers", highlight: "Best in Class" },
];

const HeroSection = () => {
  const plugin = useRef(Autoplay({ delay: 4000, stopOnInteraction: false }));

  return (
    <section id="home" className="relative">
      <Carousel
        plugins={[plugin.current]}
        opts={{ loop: true }}
        className="w-full"
      >
        <CarouselContent>
          {slides.map((slide, i) => (
            <CarouselItem key={i}>
              <div className="relative">
                <div className="absolute inset-0">
                  <img
                    src={slide.img}
                    alt={slide.alt}
                    width={1920}
                    height={800}
                    className="w-full h-full object-cover"
                    {...(i === 0 ? {} : { loading: "lazy" as const })}
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/70 to-primary/40" />
                </div>
                <div className="relative container-wide py-24 md:py-36 lg:py-44">
                  <div className="max-w-2xl text-primary-foreground">
                    <h2 className={`text-3xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 ${i === 0 ? "" : ""}`}>
                      {slide.headline}<br />
                      <span className="text-secondary">{slide.sub}</span>{" "}
                      {slide.highlight}
                    </h2>
                    <p className="text-lg md:text-xl opacity-90 mb-8 leading-relaxed">
                      15+ years of trusted printer sales, repair & maintenance. Same-day on-site service with genuine spare parts and 30-day warranty.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 text-base px-8">
                        <a href="tel:7870938693"><Phone size={18} className="mr-2" /> Call 7870938693</a>
                      </Button>
                      <Button asChild size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 text-base px-8">
                        <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer">WhatsApp Us</a>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="left-4 md:left-8 bg-primary-foreground/20 border-none text-primary-foreground hover:bg-primary-foreground/40 h-10 w-10" />
        <CarouselNext className="right-4 md:right-8 bg-primary-foreground/20 border-none text-primary-foreground hover:bg-primary-foreground/40 h-10 w-10" />
      </Carousel>
    </section>
  );
};

export default HeroSection;
