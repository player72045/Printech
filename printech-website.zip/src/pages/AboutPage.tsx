import Layout from "@/components/Layout";
import WhyChoose from "@/components/WhyChoose";
import Testimonials from "@/components/Testimonials";
import BrandsStrip from "@/components/BrandsStrip";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Calendar, Printer, MapPin } from "lucide-react";

const stats = [
  { icon: Calendar, value: "15+", label: "Years Experience" },
  { icon: Users, value: "5,000+", label: "Happy Clients" },
  { icon: Printer, value: "10,000+", label: "Printers Repaired" },
  { icon: MapPin, value: "50+", label: "Service Areas" },
];

const AboutPage = () => (
  <Layout>
    <section className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container-wide text-center">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">About Printech</h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto">
          Kolkata's most trusted printer service partner since 2010
        </p>
      </div>
    </section>

    <section className="section-padding bg-background">
      <div className="container-wide">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">Our Story</h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-4">
            Printech Imaging Solution was founded in 2010 with a simple mission: to provide reliable, affordable, and fast printer services to homes and businesses in Kolkata. What started as a small repair shop has grown into one of the city's most trusted names in printer sales, service, and maintenance.
          </p>
          <p className="text-muted-foreground text-lg leading-relaxed">
            With a team of certified technicians, genuine spare parts, and a commitment to same-day service, we've built lasting relationships with over 5,000 clients across Kolkata. From small home offices to large corporate setups, we handle it all — every brand, every model, every problem.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-surface rounded-xl p-6 text-center"
            >
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <s.icon size={28} className="text-primary" />
              </div>
              <p className="text-3xl font-bold text-primary">{s.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <WhyChoose />
    <BrandsStrip />
    <Testimonials />

    <section className="section-padding bg-surface">
      <div className="container-wide text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Ready to Work With Us?</h2>
        <p className="text-muted-foreground text-lg mb-6">Let's discuss how we can keep your printers running at peak performance.</p>
        <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Link to="/contact">Get In Touch</Link>
        </Button>
      </div>
    </section>
  </Layout>
);

export default AboutPage;
