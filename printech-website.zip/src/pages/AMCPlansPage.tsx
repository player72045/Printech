import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Check, X as XIcon } from "lucide-react";
import { motion } from "framer-motion";

const plans = [
  {
    name: "Basic",
    price: "₹2,999",
    period: "/year",
    desc: "Ideal for single home or small office printers",
    features: [
      { text: "2 preventive visits/year", included: true },
      { text: "Priority on-site support", included: true },
      { text: "10% off spare parts", included: true },
      { text: "Phone & WhatsApp support", included: true },
      { text: "Free pickup & drop", included: false },
      { text: "Unlimited service calls", included: false },
      { text: "Loaner printer", included: false },
    ],
    popular: false,
  },
  {
    name: "Standard",
    price: "₹5,999",
    period: "/year",
    desc: "Best for offices with 2–5 printers",
    features: [
      { text: "4 preventive visits/year", included: true },
      { text: "Priority on-site support", included: true },
      { text: "20% off spare parts", included: true },
      { text: "Phone & WhatsApp support", included: true },
      { text: "Free pickup & drop", included: true },
      { text: "Unlimited service calls", included: false },
      { text: "Loaner printer", included: false },
    ],
    popular: true,
  },
  {
    name: "Premium",
    price: "₹9,999",
    period: "/year",
    desc: "For businesses needing zero-downtime printing",
    features: [
      { text: "Monthly preventive visits", included: true },
      { text: "Priority on-site support", included: true },
      { text: "Free genuine spare parts", included: true },
      { text: "Phone & WhatsApp support", included: true },
      { text: "Free pickup & drop", included: true },
      { text: "Unlimited service calls", included: true },
      { text: "Loaner printer on repair", included: true },
    ],
    popular: false,
  },
];

const AMCPlansPage = () => (
  <Layout>
    <section className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container-wide text-center">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">AMC Plans</h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto">
          Annual Maintenance Contracts to keep your printers running smoothly. Choose a plan that fits your needs.
        </p>
      </div>
    </section>

    <section className="section-padding bg-surface">
      <div className="container-wide">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`bg-card rounded-xl border-2 p-6 md:p-8 relative ${plan.popular ? "border-primary shadow-lg scale-[1.02]" : "border-border"}`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-4 py-1 rounded-full">
                  Most Popular
                </span>
              )}
              <h3 className="text-xl font-bold text-foreground mb-1">{plan.name}</h3>
              <p className="text-sm text-muted-foreground mb-4">{plan.desc}</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-primary">{plan.price}</span>
                <span className="text-muted-foreground">{plan.period}</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f) => (
                  <li key={f.text} className={`flex items-center gap-2 text-sm ${f.included ? "text-foreground" : "text-muted-foreground/50"}`}>
                    {f.included ? <Check size={16} className="text-secondary shrink-0" /> : <XIcon size={16} className="shrink-0" />}
                    {f.text}
                  </li>
                ))}
              </ul>
              <Button asChild className={`w-full ${plan.popular ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-muted text-foreground hover:bg-muted/80"}`}>
                <Link to="/contact">Get Started</Link>
              </Button>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 bg-secondary/10 rounded-xl p-8 text-center">
          <h3 className="text-xl font-bold text-foreground mb-2">🚚 Free Pickup & Drop for Standard & Premium AMC Customers</h3>
          <p className="text-muted-foreground">All AMC plans include 30-day warranty on every repair. Custom plans available for offices with 10+ printers.</p>
        </div>
      </div>
    </section>
  </Layout>
);

export default AMCPlansPage;
