import Layout from "@/components/Layout";
import HeroSection from "@/components/HeroSection";
import PurchaseRental from "@/components/PurchaseRental";
import ServicesGrid from "@/components/ServicesGrid";
import WhyChoose from "@/components/WhyChoose";
import BrandsStrip from "@/components/BrandsStrip";
import Testimonials from "@/components/Testimonials";

const Index = () => (
  <Layout>
    <HeroSection />
    <PurchaseRental />
    <ServicesGrid />
    <WhyChoose />
    <BrandsStrip />
    <Testimonials />
  </Layout>
);

export default Index;
