import Layout from "@/components/Layout";
import ServicesGrid from "@/components/ServicesGrid";
import FAQSection from "@/components/FAQSection";
import WhyChoose from "@/components/WhyChoose";
import BrandsStrip from "@/components/BrandsStrip";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ServicesPage = () => (
  <Layout>
    {/* Page Hero */}
    <section className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container-wide text-center">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">Our Services</h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto mb-6">
          Complete printer solutions for homes and businesses across Kolkata — from sales to service to support.
        </p>
        <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
          <Link to="/contact">Book a Service</Link>
        </Button>
      </div>
    </section>

    <ServicesGrid />
    <WhyChoose />
    <BrandsStrip />
    <FAQSection />

    {/* Bottom CTA */}
    <section className="section-padding bg-surface">
      <div className="container-wide text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Need Printer Help?</h2>
        <p className="text-muted-foreground text-lg mb-6">Get same-day on-site service from our certified technicians.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <a href="tel:7870938693">Call 7870938693</a>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/contact">Contact Us</Link>
          </Button>
        </div>
      </div>
    </section>
  </Layout>
);

export default ServicesPage;
