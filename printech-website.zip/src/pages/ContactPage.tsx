import Layout from "@/components/Layout";
import ContactCTA from "@/components/ContactCTA";
import FAQSection from "@/components/FAQSection";

const ContactPage = () => (
  <Layout>
    <section className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container-wide text-center">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">Contact Us</h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto">
          Need help with your printer? Fill the form below or call us directly. We respond within 30 minutes.
        </p>
      </div>
    </section>

    <ContactCTA />
    <FAQSection />
  </Layout>
);

export default ContactPage;
