import Layout from "@/components/Layout";
import Products from "@/components/Products";
import BrandsStrip from "@/components/BrandsStrip";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ProductsPage = () => (
  <Layout>
    <section className="bg-primary text-primary-foreground py-16 md:py-24">
      <div className="container-wide text-center">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">Our Products</h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto mb-6">
          New & refurbished printers, toners and cartridges from all major brands at the best prices in Kolkata.
        </p>
        <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
          <a href="https://wa.me/917870938693" target="_blank" rel="noopener noreferrer">Enquire on WhatsApp</a>
        </Button>
      </div>
    </section>

    <Products />
    <BrandsStrip />

    <section className="section-padding bg-surface">
      <div className="container-wide text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Can't Find What You Need?</h2>
        <p className="text-muted-foreground text-lg mb-6">We source printers and consumables from all major brands. Tell us what you need.</p>
        <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Link to="/contact">Request a Quote</Link>
        </Button>
      </div>
    </section>
  </Layout>
);

export default ProductsPage;
